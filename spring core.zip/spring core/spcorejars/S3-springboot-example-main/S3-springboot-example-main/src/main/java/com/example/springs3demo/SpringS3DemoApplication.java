package com.example.springs3demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringS3DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringS3DemoApplication.class, args);
    }

}
