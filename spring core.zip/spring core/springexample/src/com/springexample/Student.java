package com.springexample;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Student {
	private String name;
	private String address;


	
	public Student(String name, String address) {
		super();
		this.name = name;
		this.address = address;
	}

	public void displayInfo() {
		System.out.println("Hello: " + name+" "+address);
	}
	
	/*
	 * public static void main(String[] args) {
	 * 
	 * Student s=new Student("demo1","demo2");
	 * 
	 * s.displayInfo();
	 * 
	 * }
	 */
	

	public static void main(String[] args) {  
	    Resource resource=new ClassPathResource("com/springexample/applicationContext.xml");  
	    BeanFactory factory=new XmlBeanFactory(resource);  
	      
	    Student student=(Student)factory.getBean("s");  
	    student.displayInfo();  
	} 
	
}
